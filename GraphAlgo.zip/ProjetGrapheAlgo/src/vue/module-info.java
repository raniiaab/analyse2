module ProjetGrapheAlgo
{
	requires java.desktop;
}